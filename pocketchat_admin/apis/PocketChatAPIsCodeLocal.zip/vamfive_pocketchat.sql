-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2021 at 05:17 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vamfive_pocketchat`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(2) NOT NULL,
  `name` varchar(60) NOT NULL DEFAULT 'Admin',
  `password` varchar(70) NOT NULL,
  `role_id` int(1) NOT NULL DEFAULT 2,
  `status` int(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `role_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', '6705078bff73a78a486361ae12cd05cb', 1, 1, '2020-12-27 18:23:53', NULL, NULL),
(2, 'Raja', '94de8e93b3b90b647a944e7abcbcf9a1', 2, 1, '2020-12-27 18:23:57', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int(4) NOT NULL,
  `image` text NOT NULL,
  `user_id` int(4) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 3,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(4) NOT NULL,
  `sub_id` int(2) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `sub_id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Table Manager', '2021-01-02 09:15:37', NULL, NULL),
(2, 1, 'Manual Marker', '2021-01-02 09:15:37', NULL, NULL),
(3, 1, 'Semi Assorter', '2021-01-02 09:15:37', NULL, NULL),
(4, 1, 'Aakhubhar', '2021-01-02 09:15:37', NULL, NULL),
(5, 1, 'Color Purity', '2021-01-02 09:15:37', NULL, NULL),
(6, 2, 'Sarin Capture Marking', '2021-01-02 09:15:37', NULL, NULL),
(7, 2, 'Qshi', '2021-01-02 09:15:37', NULL, NULL),
(8, 2, 'Final Galaxy Marker', '2021-01-02 09:15:37', NULL, NULL),
(9, 3, 'Rough Assorter', '2021-01-02 09:15:37', NULL, NULL),
(10, 3, 'Craft Assorter', '2021-01-02 09:15:37', NULL, NULL),
(11, 3, 'Polish Assorter', '2021-01-02 09:15:37', NULL, NULL),
(12, 4, 'Operator', '2021-01-02 09:15:37', NULL, NULL),
(13, 4, 'Capture & Marking', '2021-01-02 09:15:37', NULL, NULL),
(14, 4, 'Boil Inclusion', '2021-01-02 09:15:37', NULL, NULL),
(15, 4, 'Sarin 4P Marker', '2021-01-02 09:15:37', NULL, NULL),
(16, 5, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(17, 5, 'Sawing Checker', '2021-01-02 09:15:37', NULL, NULL),
(18, 5, 'Operator', '2021-01-02 09:15:37', NULL, NULL),
(19, 5, 'Teaching', '2021-01-02 09:15:37', NULL, NULL),
(20, 6, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(21, 6, '4P Checker', '2021-01-02 09:15:37', NULL, NULL),
(22, 6, 'Operator', '2021-01-02 09:15:37', NULL, NULL),
(23, 6, 'Teaching', '2021-01-02 09:15:37', NULL, NULL),
(24, 7, 'Boil', '2021-01-02 09:15:37', '2021-01-02 16:17:00', NULL),
(25, 8, 'Kanti', '2021-01-02 09:15:37', '2021-01-02 16:17:06', NULL),
(26, 9, 'Data Entry', '2021-01-02 09:15:37', '2021-01-02 16:17:15', NULL),
(27, 10, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(28, 10, 'Blocking Manager', '2021-01-02 09:15:37', NULL, NULL),
(29, 10, 'Chapka Karigar', '2021-01-02 09:15:37', NULL, NULL),
(30, 11, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(31, 11, '4P Table Polisher', '2021-01-02 09:15:37', NULL, NULL),
(32, 12, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(33, 12, 'Russian Operator', '2021-01-02 09:15:37', NULL, NULL),
(34, 13, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(35, 13, 'Diy Fixing', '2021-01-02 09:15:37', NULL, NULL),
(36, 13, 'Taliya Polisher', '2021-01-02 09:15:37', NULL, NULL),
(37, 14, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(38, 14, 'Pel Polisher', '2021-01-02 09:15:37', NULL, NULL),
(39, 15, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(40, 15, 'Mathala Polisher', '2021-01-02 09:15:37', NULL, NULL),
(41, 16, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(42, 16, 'Half Xxx Polisher', '2021-01-02 09:15:37', NULL, NULL),
(43, 16, 'Full Xxx Polisher', '2021-01-02 09:15:37', NULL, NULL),
(44, 17, 'Manager', '2021-01-02 09:15:37', NULL, NULL),
(45, 17, 'Fancy Polisher', '2021-01-02 09:15:37', NULL, NULL),
(46, 18, 'Dori', '2021-01-02 09:15:37', '2021-01-02 16:17:25', NULL),
(47, 19, 'Polish Checker', '2021-01-02 09:15:37', '2021-01-02 16:17:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(4) NOT NULL,
  `user_id` int(4) NOT NULL,
  `category_id` int(4) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `cur_cmp` varchar(60) NOT NULL,
  `cur_sal` text NOT NULL,
  `birth_date` date NOT NULL,
  `native_place` varchar(60) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `user_id`, `category_id`, `fname`, `lname`, `cur_cmp`, `cur_sal`, `birth_date`, `native_place`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 19, 'Chirag', 'Ramchandaee', 'VAM5', '1', '1996-09-28', 'Kalol', '2021-01-02 12:12:21', '2021-01-02 16:06:21', NULL),
(2, 1, 19, 'Chirag', 'Ramchandaee', 'VAM5', '1', '1996-09-28', 'Kalol', '2021-01-02 12:13:37', '2021-01-02 16:06:21', NULL),
(3, 1, 19, 'Chirag', 'Ramchandaee', 'VAM5', '1', '1996-09-28', 'Kalol', '2021-01-02 15:56:01', '2021-01-02 16:06:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `maincategories`
--

CREATE TABLE `maincategories` (
  `id` int(4) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maincategories`
--

INSERT INTO `maincategories` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Office Department', '2021-01-02 06:38:36', NULL, NULL),
(2, 'Factory Department', '2021-01-02 06:38:36', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE `owners` (
  `id` int(4) NOT NULL,
  `user_id` int(4) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `cmp_name` varchar(60) NOT NULL,
  `cmp_address` text NOT NULL,
  `position` varchar(60) NOT NULL,
  `native_place` varchar(60) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`id`, `user_id`, `fname`, `lname`, `cmp_name`, `cmp_address`, `position`, `native_place`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Chirag', 'Ramchandanee', 'VAM5', 'Home', 'Graphic Designer', 'Isand', '2021-01-02 07:42:26', '2021-01-02 07:43:37', NULL),
(2, 1, 'Chirag', 'Ramchandanee', 'VAM5', 'Home', 'Graphic Designer', 'Isand', '2021-01-02 07:43:47', '2021-01-02 08:01:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `access_lv` int(1) NOT NULL DEFAULT 3,
  `status` int(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `access_lv`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Super Admin', 1, 1, '2020-12-27 11:53:50', NULL, NULL),
(2, 'Admin', 2, 1, '2020-12-27 11:53:51', NULL, NULL),
(3, 'Owner', 3, 1, '2020-12-27 11:53:52', NULL, NULL),
(4, 'Employee', 4, 1, '2020-12-27 11:53:52', NULL, NULL),
(5, 'User', 0, 2, '2020-12-27 11:53:53', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(4) NOT NULL,
  `main_id` int(2) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `main_id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Marker', '2021-01-02 06:47:57', NULL, NULL),
(2, 1, 'Galaxy', '2021-01-02 06:47:57', NULL, NULL),
(3, 1, 'Assorter', '2021-01-02 06:47:57', NULL, NULL),
(4, 1, 'Sarin', '2021-01-02 06:47:57', NULL, NULL),
(5, 1, 'Laser', '2021-01-02 06:47:57', NULL, NULL),
(6, 1, '4P', '2021-01-02 06:47:57', NULL, NULL),
(7, 1, 'Boil', '2021-01-02 06:47:57', NULL, NULL),
(8, 1, 'Kanti', '2021-01-02 06:47:57', NULL, NULL),
(9, 1, 'Data Entry', '2021-01-02 06:47:57', NULL, NULL),
(10, 2, 'Blocking', '2021-01-02 06:47:57', NULL, NULL),
(11, 2, 'Table', '2021-01-02 06:47:57', NULL, NULL),
(12, 2, 'Russian', '2021-01-02 06:47:57', NULL, NULL),
(13, 2, 'Taliya', '2021-01-02 06:47:57', NULL, NULL),
(14, 2, 'Pel', '2021-01-02 06:47:57', NULL, NULL),
(15, 2, 'Mathala', '2021-01-02 06:47:57', NULL, NULL),
(16, 2, 'Xxx', '2021-01-02 06:47:57', NULL, NULL),
(17, 2, 'Fancy', '2021-01-02 06:47:57', NULL, NULL),
(18, 2, 'Dori', '2021-01-02 06:47:57', NULL, NULL),
(19, 2, 'Polish Checker', '2021-01-02 06:47:57', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(4) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `device_token` text NOT NULL,
  `cmp_name` varchar(191) DEFAULT NULL,
  `cmp_address` text DEFAULT NULL,
  `role_id` int(4) DEFAULT 5 COMMENT '5 is for Simple level access',
  `image` text NOT NULL DEFAULT 'avatar-1.png',
  `created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `phone`, `name`, `device_token`, `cmp_name`, `cmp_address`, `role_id`, `image`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '9974896992', 'Chirag Ramchandaee', '', 'VAM5', 'Home', 4, '9974896992.png', '2020-12-27 09:54:12', '2021-01-02 12:10:22', NULL),
(2, '9328380278', NULL, '', NULL, NULL, 5, 'avatar-1.png', '2020-12-30 06:13:18', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_auth`
--

CREATE TABLE `user_auth` (
  `id` int(4) NOT NULL,
  `otp` text NOT NULL,
  `verified` int(1) NOT NULL DEFAULT 0 COMMENT 'when verified make 1 ',
  `phone` varchar(14) NOT NULL COMMENT 'mobile no of user',
  `otp_created_at` timestamp NOT NULL DEFAULT convert_tz(current_timestamp(),'SYSTEM','+05:30'),
  `otp_verified_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_auth`
--

INSERT INTO `user_auth` (`id`, `otp`, `verified`, `phone`, `otp_created_at`, `otp_verified_at`) VALUES
(1, '8337', 1, '9974896992', '2020-12-27 09:54:13', '2020-12-27 09:54:39'),
(2, '9095', 1, '9328380278', '2020-12-30 06:13:27', '2020-12-30 00:44:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maincategories`
--
ALTER TABLE `maincategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_auth`
--
ALTER TABLE `user_auth`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `maincategories`
--
ALTER TABLE `maincategories`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_auth`
--
ALTER TABLE `user_auth`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
